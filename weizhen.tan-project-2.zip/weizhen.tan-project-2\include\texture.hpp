#pragma once    

// TODO: loading textures and import SOIL library https://github.com/littlstar/soil
class Texture 
{

public:

    Texture()   {};
    ~Texture()  {};

};
